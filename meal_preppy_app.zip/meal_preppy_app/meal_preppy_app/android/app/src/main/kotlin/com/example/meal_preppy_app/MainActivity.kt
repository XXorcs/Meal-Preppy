package com.example.meal_preppy_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
