import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MealPreppyScreen(),
    );
  }
}

class MealPreppyScreen extends StatefulWidget {
  const MealPreppyScreen({super.key});

  @override
  _MealPreppyScreenState createState() => _MealPreppyScreenState();
}

class _MealPreppyScreenState extends State<MealPreppyScreen> {
  final Map<String, String> _bfastImages = {
    'assets/bfast/1.jpg': 'Nilagang Saba',
    'assets/bfast/2.jpg': 'Champorado',
    'assets/bfast/3.jpg': 'Pancakes',
    'assets/bfast/4.jpg': 'Tapsilog',
    'assets/bfast/5.jpg': 'Pandesal',
    'assets/bfast/6.jpg': 'Cereal',
    'assets/bfast/7.jpg': 'Caesar Salad',
  };

  final Map<String, String> _lunchImages = {
    'assets/lunch/l1.jpg': 'Clubhouse Sandwich',
    'assets/lunch/l2.jpg': 'Sinigang',
    'assets/lunch/l3.jpg': 'Inihaw na Pusit',
    'assets/lunch/l4.jpg': 'Chicken Barbecue',
    'assets/lunch/l5.jpg': 'Tinolang Manok',
    'assets/lunch/l6.jpg': 'Charred Chicken',
    'assets/lunch/l7.jpg': 'Pancit',
  };

  final Map<String, String> _drinksImages = {
    'assets/drinks/d1.jpg': 'Milk',
    'assets/drinks/d2.jpg': 'Coffee',
    'assets/drinks/d3.jpg': 'Smoothie',
    'assets/drinks/d4.jpg': 'MilkTea',
    'assets/drinks/d5.jpg': 'Matcha Latte',
    'assets/drinks/d6.jpg': 'Orange Juice',
    'assets/drinks/d7.jpg': 'Water',
    'assets/drinks/d8.jpg': 'Iced Coffee',
    'assets/drinks/d9.jpg': 'Lemon Water',
  };

  final Map<String, String> _dessertImages = {
    'assets/dessert/des1.jpg': 'Blueberry Muffin',
    'assets/dessert/des2.jpg': 'Chocolate Muffin',
    'assets/dessert/des3.jpg': 'Choco Crepes',
    'assets/dessert/des4.jpg': 'Brownies',
    'assets/dessert/des5.jpg': 'No Dessert for Today!',
    'assets/dessert/des6.jpg': 'Suman',
  };

  final Map<String, String> _dinnerImages = {
    'assets/dinner/din1.jpg': 'Shrimp Fried Rice',
    'assets/dinner/din2.jpg': 'Monggo',
    'assets/dinner/din3.jpg': 'Fried Chicken',
    'assets/dinner/din4.jpg': 'Chopseuy',
    'assets/dinner/din5.jpg': 'Pork Menudo',
    'assets/dinner/din6.jpg': 'Pasta with Mushroom',
    'assets/dinner/din7.jpg': 'Salmon with Rice',
  };

  final Map<String, String> _snacksImages = {
    'assets/snacks/s1.jpg': 'Biscuit',
    'assets/snacks/s2.jpg': 'Siomai',
    'assets/snacks/s3.jpg': 'Turon',
    'assets/snacks/s4.jpg': 'Takoyaki',
    'assets/snacks/s5.jpg': 'Fruits',
    'assets/snacks/s6.jpg': 'Cookies',
    'assets/snacks/s7.jpg': 'Peanut Butter and Jelly Sandwich',
  };

  late String _currentSideImage;
  late String _currentDessertImage;
  late String _currentDrinkImage;
  late String _bottomImage;

  late String _currentSideTitle;
  late String _currentDessertTitle;
  late String _currentDrinkTitle;

  String _selectedCategory = 'Breakfast';
  String _calloutText = '';

  @override
  void initState() {
    super.initState();
    _currentSideImage = 'assets/babyathy.jpg';
    _currentDessertImage = 'assets/babyathy.jpg';
    _currentDrinkImage = 'assets/babyathy.jpg';
    _bottomImage = 'assets/shomked.jpg';

    _currentSideTitle = '';
    _currentDessertTitle = '';
    _currentDrinkTitle = '';
    _calloutText = '';
  }

  void _randomizeImages() {
    setState(() {
      const invalidImage = 'assets/ghastly.jpg';
      _bottomImage = invalidImage;
      _calloutText = '';

      String normalizedCategory = _selectedCategory.toLowerCase();
      bool isValidCategory = ['breakfast', 'lunch', 'dinner', 'snacks'].contains(normalizedCategory);

      if (isValidCategory) {
        if (normalizedCategory == 'snacks') {
          _currentSideImage = _snacksImages.keys.elementAt(Random().nextInt(_snacksImages.length));
          _currentSideTitle = _snacksImages[_currentSideImage]!;
        } else if (normalizedCategory == 'breakfast') {
          _currentSideImage = _bfastImages.keys.elementAt(Random().nextInt(_bfastImages.length));
          _currentSideTitle = _bfastImages[_currentSideImage]!;
        } else if (normalizedCategory == 'lunch') {
          _currentSideImage = _lunchImages.keys.elementAt(Random().nextInt(_lunchImages.length));
          _currentSideTitle = _lunchImages[_currentSideImage]!;
        } else if (normalizedCategory == 'dinner') {
          _currentSideImage = _dinnerImages.keys.elementAt(Random().nextInt(_dinnerImages.length));
          _currentSideTitle = _dinnerImages[_currentSideImage]!;
        }

        _currentDrinkImage = _drinksImages.keys.elementAt(Random().nextInt(_drinksImages.length));
        _currentDrinkTitle = _drinksImages[_currentDrinkImage]!;

        _currentDessertImage = _dessertImages.keys.elementAt(Random().nextInt(_dessertImages.length));
        _currentDessertTitle = _dessertImages[_currentDessertImage]!;

        _bottomImage = 'assets/shomked.jpg';

        if (_currentDessertImage == 'assets/dessert/des5.jpg') {
          _bottomImage = 'assets/ghastly.jpg';
          _calloutText = 'Athy wants desserts.';
        } else if (_currentDessertImage == 'assets/dessert/des2.jpg' ||
            _currentDessertImage == 'assets/dessert/des3.jpg' ||
            _currentDessertImage == 'assets/dessert/des4.jpg' ||
            _currentSideImage == 'assets/snacks/s6.jpg' ||
            _currentSideImage == 'assets/snacks/s1.jpg') {
          _bottomImage = 'assets/choco.jpg';
          _calloutText = 'Athy wants Chocolates!';
        } else if (_bottomImage == 'assets/shomked.jpg') {
          _calloutText = 'Athy likes that tooo!';
        }
      } else {

        _currentSideImage = invalidImage;
        _currentSideTitle = 'No Image Available';
        _currentDessertImage = invalidImage;
        _currentDessertTitle = 'No Image Available';
        _currentDrinkImage = invalidImage;
        _currentDrinkTitle = 'No Image Available';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    bool showCallout = _bottomImage != 'assets/ghastly.jpg' || _calloutText.isNotEmpty;


    return Scaffold(
      backgroundColor: Color.fromRGBO(245, 218, 223, 100),
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
        title: const Text(
          "Meal Preppy!",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Let's Eat!",
              style: TextStyle(
                fontSize: 28,
                color: Color.fromRGBO(36, 35, 51, 100)
          ),
        ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Enter a category (Breakfast, Lunch, Dinner, Snacks)',
                    border: OutlineInputBorder(),
                  ),
                  onSubmitted: (value) {
                    setState(() {
                      _selectedCategory = value.trim();
                      _randomizeImages();
                    });
                  },
                ),
              ),
              SizedBox(height: 20),
              GridView(
                padding: EdgeInsets.all(20),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, // Fixed 3 columns
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: Container(
                          width: double.infinity,
                          height: 100,
                          child: Image.asset(
                            _currentSideImage,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(_currentSideTitle),
                    ],
                  ),
                  Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: Container(
                          width: double.infinity,
                          height: 100,
                          child: Image.asset(
                            _currentDessertImage,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(_currentDessertTitle),
                    ],
                  ),
                  Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: Container(
                          width: double.infinity,
                          height: 100,
                          child: Image.asset(
                            _currentDrinkImage,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(_currentDrinkTitle),
                    ],
                  ),
                ],
              ),
              Spacer(), // Pushes the footer to the bottom
              Stack(
                alignment: Alignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 150),
                    child: Image.asset(
                      _bottomImage,
                      width: 150,
                      height: 150,
                      fit: BoxFit.cover,
                    ),
                  ),
                  if (showCallout && _calloutText.isNotEmpty)
                    Positioned(
                      bottom: 100, // Adjust the position as needed
                      child: Container(
                        width: 150,
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Color.fromRGBO(108, 106, 160, 90),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          _calloutText,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  'Random meal ft. Athanasia!',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
